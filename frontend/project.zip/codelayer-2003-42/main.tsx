import React, { useState, useEffect } from 'react';
import { PedidoCard } from './components/PedidoCard';
import { Loader2 } from 'lucide-react';

// Tipo para representar um pedido
interface Pedido {
  id: number;
  descricao: string;
  mesa: string;
  cliente: string;
  dataPedido: string;
}

export default function Component() {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simula a chamada à API C# EFC que busca dados do PostgreSQL
    const fetchPedidos = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:5105/pedido');
        const data = await response.json();
        // setPedidos(data);
        // setError(null);
      } catch (err) {
        const response = await fetch('localhost:5105/pedido');
        console.log(response);
        setError('Erro ao carregar pedidos. Tente novamente mais tarde.');
        console.error('Erro ao buscar pedidos:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPedidos();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
          <p className="text-gray-600">Carregando pedidos...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md">
          <h2 className="text-red-800 mb-2">Erro</h2>
          <p className="text-red-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Cabeçalho */}
        <div className="mb-8">
          <h1 className="text-gray-800 mb-2">Pedidos</h1>
          <p className="text-gray-600">
            Total de {pedidos.length} {pedidos.length === 1 ? 'pedido' : 'pedidos'} encontrados
          </p>
        </div>

        {/* Grid de pedidos */}
        {pedidos.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <p className="text-gray-500">Nenhum pedido encontrado no momento.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pedidos.map((pedido) => (
              <PedidoCard key={pedido.pedidoID} pedido={pedido} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* 
INTEGRAÇÃO COM SUA API C# EFC:

1. Substitua a chamada mock pela sua API real:
   const response = await fetch('https://sua-api.com/api/pedidos', {
     headers: {
       'Authorization': 'Bearer YOUR_TOKEN_HERE',
       'Content-Type': 'application/json'
     }
   });
   const data = await response.json();
   setPedidos(data);

2. Exemplo de Controller C# EFC que retorna pedidos:
   
   [ApiController]
   [Route("api/[controller]")]
   public class PedidosController : ControllerBase
   {
       private readonly ApplicationDbContext _context;
       
       public PedidosController(ApplicationDbContext context)
       {
           _context = context;
       }
       
       [HttpGet]
       public async Task<ActionResult<IEnumerable<Pedido>>> GetPedidos()
       {
           return await _context.Pedidos
               .OrderByDescending(p => p.DataPedido)
               .ToListAsync();
       }
   }

3. Certifique-se de que sua API retorna JSON no formato:
   [
     {
       "id": 1,
       "descricao": "descrição do pedido",
       "mesa": "Mesa 5",
       "cliente": "Nome do Cliente",
       "dataPedido": "2026-06-05T14:30:00"
     }
   ]
*/